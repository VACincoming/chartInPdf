To start project you need:
npm run dev

To run tests write
npm run test