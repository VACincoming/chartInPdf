import React from 'react';
import './App.css';
import Chart from './Components/Chart'

function App() {
  return (
    <>
      <Chart />
    </>
  );
}

export default App;
